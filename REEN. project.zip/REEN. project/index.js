$(document).ready(function(){

$(".hide").click(function(){
$("h4").hide();
});
$(".show").click(function(){
  $("h4").show();
})
$("h4").mouseenter(function(){
alert("you a progremar");
})
});
